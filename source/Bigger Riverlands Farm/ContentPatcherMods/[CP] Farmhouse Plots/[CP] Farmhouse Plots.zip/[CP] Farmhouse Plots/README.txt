Changelog

- v1.1 (Spouse Room Update)
	- Added Spouse Rooms
	- Main Farmhouse now has farmland
- v1.0 (Initial Release)
	- Initial Release
	- Farm in cabins
﻿$version= Get-Content .\manifest.json | ConvertFrom-Json | Select-Object Version;
if(Test-Path "./release"){
   mkdir -Path "./release"
}
$releaseDir = Get-Item -LiteralPath "./release";

$expected="./release/[CP] Resources Generators $version.zip"

if(Test-Path $expected){
   Remove-Item -Path $expected -Confirm
}

7z a -tzip "./release/[CP] Resources Generators" -mx0 -xr!".idea" -xr!".psd" -xr!"Folder.DotSettings.user" -xr!"zip.bat" -xr!"release"

Pause
For cross-compatibility with other mods, Sundrop bundles different patches:

Vanilla.tbin
- For vanilla SDV, also used if a mod that is not supported has edited the Town map
- The version of town used for this patch is the vanilla SDV one, credit belongs to CA!

KarmyllaImmersive.tbin
- Used when "Karmylla's Immersive Maps" is loaded
- The modified version of town used for this patch was created by them, any credit is theirs!